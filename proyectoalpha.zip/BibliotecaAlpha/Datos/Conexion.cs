﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    internal class Conexion
    {
        internal static string strConexion = @"Server=(LocalDB)\MSSQLLocalDB;database=BibliotecaSQL;Integrated Security=true"; 
    }
}
